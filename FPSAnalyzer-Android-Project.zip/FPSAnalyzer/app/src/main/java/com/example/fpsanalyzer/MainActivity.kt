package com.example.fpsanalyzer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var fps: TextView
    private lateinit var details: TextView
    private lateinit var chooseButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 18, 22)
        window.navigationBarColor = Color.rgb(16, 18, 22)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
            setBackgroundColor(Color.rgb(16, 18, 22))
        }
        val title = text("FPS ANALYZER", 25f, Color.WHITE, true)
        val subtitle = text("Calcula los fotogramas por segundo de un vídeo", 14f, 0xFFADB4C0.toInt())
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(0, dp(10), 0, dp(28))
        chooseButton = Button(this).apply {
            text = "SELECCIONAR VÍDEO"
            isAllCaps = false
            setOnClickListener { openVideo() }
        }
        status = text("Ningún vídeo seleccionado", 15f, 0xFFADB4C0.toInt())
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(28), 0, dp(10))
        fps = text("— FPS", 42f, 0xFF65C9FF.toInt(), true).apply { gravity = Gravity.CENTER }
        details = text("El resultado del análisis aparecerá aquí.", 14f, 0xFFADB4C0.toInt())
        details.gravity = Gravity.CENTER
        details.setPadding(0, dp(18), 0, 0)
        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(chooseButton, matchWrap())
        root.addView(status, matchWrap())
        root.addView(fps, matchWrap())
        root.addView(details, matchWrap())
        setContentView(root)
    }

    private fun openVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, REQUEST_VIDEO)
    }

    @Deprecated("Deprecated by platform, retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            analyze(uri)
        }
    }

    private fun analyze(uri: Uri) {
        chooseButton.isEnabled = false
        status.text = "Analizando…"
        fps.text = "…"
        details.text = "Leyendo las marcas de tiempo de los fotogramas."
        worker.execute {
            val result = try { inspectVideo(uri) } catch (e: Exception) {
                AnalysisResult(error = e.localizedMessage ?: "No se pudo analizar este vídeo.")
            }
            runOnUiThread {
                chooseButton.isEnabled = true
                if (result.error != null) {
                    status.text = "No se pudo completar el análisis"
                    fps.text = "— FPS"
                    details.text = result.error
                } else {
                    status.text = result.fileName
                    fps.text = String.format(Locale.US, "%.3f FPS", result.averageFps)
                    val kind = if (result.variable) "Frecuencia variable (VFR)" else "Frecuencia aparentemente constante (CFR)"
                    details.text = "$kind\nFotogramas analizados: ${result.frameCount}\nDuración medida: ${String.format(Locale.US, "%.2f", result.durationSeconds)} s\nIntervalo entre fotogramas: ${String.format(Locale.US, "%.2f", result.minFrameMs)}–${String.format(Locale.US, "%.2f", result.maxFrameMs)} ms"
                }
            }
        }
    }

    private fun inspectVideo(uri: Uri): AnalysisResult {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(this, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) { track = i; format = f; break }
            }
            if (track < 0) return AnalysisResult(error = "No se encontró una pista de vídeo compatible.")
            extractor.selectTrack(track)
            val timestamps = ArrayList<Long>()
            while (true) {
                val t = extractor.sampleTime
                if (t < 0) break
                timestamps.add(t)
                if (!extractor.advance()) break
            }
            if (timestamps.size < 2) return AnalysisResult(error = "El vídeo no contiene suficientes fotogramas para calcular los FPS.")
            val sorted = timestamps.sorted()
            val deltas = ArrayList<Long>()
            for (i in 1 until sorted.size) {
                val d = sorted[i] - sorted[i - 1]
                if (d > 0) deltas.add(d)
            }
            if (deltas.isEmpty()) return AnalysisResult(error = "No se pudieron obtener intervalos válidos entre fotogramas.")
            val first = sorted.first()
            val last = sorted.last()
            val durationUs = last - first
            if (durationUs <= 0) return AnalysisResult(error = "La duración de los fotogramas no es válida.")
            val average = (sorted.size - 1).toDouble() * 1_000_000.0 / durationUs.toDouble()
            val minDelta = deltas.minOrNull()!!
            val maxDelta = deltas.maxOrNull()!!
            val median = deltas.sorted()[deltas.size / 2].toDouble()
            val variable = deltas.any { abs(it - median) > maxOf(1_000.0, median * 0.02) }
            val name = queryDisplayName(uri)
            return AnalysisResult(
                fileName = name,
                averageFps = average,
                frameCount = sorted.size,
                durationSeconds = durationUs / 1_000_000.0,
                minFrameMs = minDelta / 1_000.0,
                maxFrameMs = maxDelta / 1_000.0,
                variable = variable
            )
        } finally { extractor.release() }
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: "Vídeo analizado" else "Vídeo analizado"
            } ?: "Vídeo analizado"
        } catch (_: Exception) { "Vídeo analizado" }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { worker.shutdown(); super.onDestroy() }

    data class AnalysisResult(
        val fileName: String = "Vídeo analizado", val averageFps: Double = 0.0,
        val frameCount: Int = 0, val durationSeconds: Double = 0.0,
        val minFrameMs: Double = 0.0, val maxFrameMs: Double = 0.0,
        val variable: Boolean = false, val error: String? = null
    )
    companion object { private const val REQUEST_VIDEO = 41 }
}
