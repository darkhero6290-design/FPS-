# FPS Analyzer

Aplicación Android mínima para seleccionar un vídeo y estimar su frecuencia de fotogramas a partir de las marcas de tiempo de las muestras de la pista de vídeo. No incluye reproductor ni editor.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK Platform 35

## Compilar APK
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice y descargue el Android Gradle Plugin/Kotlin plugin.
3. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Notas técnicas
- La app solicita un vídeo mediante el selector de documentos de Android; no necesita permiso general de almacenamiento.
- Recorre las muestras de la pista de vídeo y usa sus timestamps para calcular FPS promedio y variación de intervalos.
- Los resultados dependen de los timestamps y del soporte del contenedor/códec en la versión de Android. La etiqueta CFR/VFR es una heurística, no una certificación del estándar del archivo.
